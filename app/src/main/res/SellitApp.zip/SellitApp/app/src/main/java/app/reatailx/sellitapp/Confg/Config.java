package app.reatailx.sellitapp.Confg;

public class Config {
    private static final String URL = "https://sellit.co.in/logisticapi/";               // Test data url old
    public static final String GET_LEADDESCRIPTION_LIST = URL + "v1/leaddescription.php";
    public static final String GET_ALLLEADS_LIST = URL + "v1/allleads.php";
    public static final String GET_VENDORLOGIN = URL + "v1/vendorlogin.php";
}

